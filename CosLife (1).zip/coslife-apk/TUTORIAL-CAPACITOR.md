# CosLife no Capacitor — tutorial completo

Este pacote já tem tudo pronto: o app (`www/`), o código nativo do Android (`native/`),
o ícone do Cosi (`assets/` e `ICONE-CosLife.png`) e o gerador de APK (`.github/workflows/build.yml`).

> ⚠️ O código nativo (Java) **ainda não foi compilado nem testado em um celular**.
> O primeiro build pode acusar algum erro simples. O tutorial mostra como ler o erro.

---

## Parte 1 — Gerar o APK sem instalar nada (recomendado)

1. Crie uma conta grátis em **github.com** e clique em **New repository** (nome: `coslife`).
2. Descompacte o `coslife-apk.zip`. Na página do repositório, clique em **uploading an existing file**
   e arraste **todo o conteúdo** da pasta (inclua `.github`, `www`, `native` e `assets`). Clique em **Commit changes**.
   - Se a pasta `.github` não subir pelo navegador, crie o arquivo `.github/workflows/build.yml`
     manualmente (**Add file → Create new file**) colando o conteúdo.
3. Aba **Actions** → **Gerar APK** → **Run workflow**.
4. Espere ~5–10 min. Verde = deu certo. Abra a execução e baixe **coslife-apk** (Artifacts).
5. Descompacte, mande `app-debug.apk` para o celular e instale (permita "fontes desconhecidas").

**O que o build faz sozinho:** instala o Capacitor → cria o projeto Android → copia o código nativo e
ajusta permissões (`native/apply-native.sh`) → gera os ícones do Cosi → compila o APK.

**Se o build ficar vermelho:** abra a execução, clique no passo vermelho e leia as últimas linhas.
Me mande o texto do erro que eu corrijo.

---

## Parte 2 — Ligar cada recurso no celular (passo a passo)

Abra o CosLife → botão **🔒** (canto de cima) → cartão **📱 Recursos do aplicativo (APK)**.

### 2.1 Cosi flutuante (Kotlin/Java + permissão + serviço + desenho animado)
1. Toque em **Ativar**. O Android abre **"Exibir sobre outros apps"**.
2. Ative a chave do **CosLife** e volte ao app.
3. Toque em **Ativar** de novo. Aparece a notificação fixa **"Cosi está ativo"** (o Android obriga).
4. Saia do app (botão Home): o Cosi aparece andando por cima dos outros apps.
5. Toque nele para abrir o CosLife. Segure e arraste para mudar de lugar.
6. Para parar: **Desativar** no app ou **Parar** na notificação.

Não aparece? Confira: permissão "Exibir sobre outros apps" ligada · notificação "Cosi está ativo" presente ·
economia de bateria do CosLife em **"Sem restrições"** · tela desbloqueada (sobre a tela de bloqueio ele não aparece).

### 2.2 Lembretes com o app fechado
1. Na aba **Hoje**, ligue os **Lembretes** e escolha antecedência.
2. Em Configurações → **Agendar agora** e permita as notificações.
3. Android 12+: **Configurações do celular → Apps → CosLife → Alarmes e lembretes → Permitir**.
4. **Bateria → Sem restrições** para o CosLife (Xiaomi/Samsung/Huawei matam apps em segundo plano).
Os lembretes são reagendados sozinhos quando você muda o planejamento (próximos 7 dias).

### 2.3 Biometria
1. Ative o **PIN** (cartão de PIN).
2. Em Configurações, digite o PIN no cartão **Biometria** → **Ativar biometria** → confirme com a digital/rosto.
3. Na próxima abertura, a biometria é pedida automaticamente. O botão **Usar biometria** repete o pedido
   e o **PIN continua funcionando** como alternativa.
Se você cadastrar uma nova digital no celular, a biometria precisa ser ativada de novo (segurança do Android).

### 2.4 Backup em arquivo
- **Exportar arquivo** → escolha onde salvar (Drive, WhatsApp, e-mail…). Com PIN ativo, o arquivo sai criptografado.
- **Restaurar:** escolha o arquivo `.json` (e digite o PIN do backup, se tiver).

---

## Parte 3 — Rodar no computador com Android Studio (opcional, ótimo para achar erros)

Precisa de Node 20, Java 17 e Android Studio. No terminal, dentro da pasta do projeto:

```bash
npm install
npx cap add android
bash native/apply-native.sh        # no Windows use o Git Bash ou WSL
npx capacitor-assets generate --android --iconBackgroundColor '#6750a4' --splashBackgroundColor '#6750a4'
npx cap sync android
npx cap open android               # abre o Android Studio → botão Run ▶ com o celular conectado por USB
```
Erros do app aparecem no **Logcat** (filtre por `Capacitor` ou `CosiOverlay`).
Depois de mudar o `www/index.html`: `npx cap sync android` e Run de novo.

---

## Parte 4 — O que cada arquivo faz

| Arquivo | Função |
|---|---|
| `www/index.html` | O app CosLife (com o Cosi, PIN, backup etc.) |
| `www/cosi-overlay.html` | O mesmo boneco animado, mostrado no Cosi flutuante |
| `native/CosiNativePlugin.java` | Ponte JS↔Android: permissão, iniciar/parar o Cosi flutuante, biometria |
| `native/CosiOverlayService.java` | Serviço em 1º plano: notificação fixa + janela do Cosi sobre outros apps |
| `native/patch.py` / `apply-native.sh` | Copiam o código, liberam permissões, registram o plugin |
| `assets/` | Ícone do Cosi (coelho de cachecol azul + "Cosi") e tela de abertura |
| `.github/workflows/build.yml` | Gera o APK no GitHub |

**Por que Java e não Kotlin?** O projeto Android do Capacitor já vem em Java. Escrever em Java dispensa
configurar Kotlin no Gradle e reduz o risco de erro de build. O resultado para o usuário é o mesmo.

---

## Parte 5 — Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Build vermelho | Ler o passo vermelho em **Actions** e me enviar o erro |
| Ícone padrão do Capacitor | Confirme que a pasta `assets/` subiu e que o passo `capacitor-assets` rodou |
| Cosi não aparece | Permissão "Exibir sobre outros apps", bateria sem restrições, app **fechado** (ele some com o app aberto) |
| Cosi some depois de um tempo | O fabricante matou o serviço: libere o app na bateria / "iniciar automaticamente" |
| Lembretes não chegam | Permissão de notificações + "Alarmes e lembretes" + bateria sem restrições |
| Biometria pede de novo | Foi cadastrada nova digital: ative a biometria outra vez |

---

## Parte 6 — Próximos passos
- Testar tudo no celular e corrigir o que aparecer.
- Versão de **release** assinada (keystore) para instalar/atualizar sem avisos e, se quiser, publicar na Play Store.
- iPhone: o Cosi flutuante não é permitido pela Apple (seria widget/notificação).
